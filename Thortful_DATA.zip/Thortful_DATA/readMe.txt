The function of this readme is to help run and test the Rest Api created for the code challenge proposed by Thortful.


In order to test this Api, a running MySql database is required. There are printscreens in the folder showing how it was created.

db name : thortful
db user: Thortful
db password: Password
port : 3306



After the db is up and running we can start testing the Api.


As a 3rd party Api, I used the Rest Countries Api, the Pokemon Api and the World Time Api.

Rest Countries Api has a vast ammount of different endpoints that allow you to search for several informations about most, if not all, countries in the world.
Pokemon Api allows you to search for tons of information about all pokemons.
And finnaly, World Time Api returns the specific time for the desired countries.


The created Api is all about countries, it gets information about any country desired and allows us to add that information to a database to further update it, retrieve it or even delete it. It also adds a little fun twist by randomly adding a Pokemon to each created country in the db.
It contains 8 endpoints, all the with base path "/country".


Using the prints sent in the folder "Testing" you can check all the working endpoints and how they change our db. We start the test with the countries Spain and France already in the db ("StartingData"). Now lets add Portugal.



We start by running "/allData/{country}" with Portugal as the path variable, this will give use to the Rest Countries Api, by sending us detailed information about Portugal ("allData"). 
But we don't need all this information in the db, so now we call "/summarizedData/{country}" to get just the most important ones ("summarizedData").

Now that we know the information we want to add, lets use it as a body for the create. We call "/create" with the body returned in the previous step, with a small change, "currencies" and "languages" need to be inputed as Lists and not Maps, as we want cleaner information to be added.
This will also use the Pokemon Api and add a random pokemon to Portugal, this way we can compare which country gets the stronger pokemon for a little fun. In this case we got "metapod" , check on print ("create").

Example:
{
    "name": "Portugal",
    "flag": "🇵🇹",
    "capital": [
        "Lisbon"
    ],
    "continents": [
        "Europe"
    ],
    "area": 92090.0,
    "currencies":[
            "Euro"
        ],
    "languages": [
        "Portuguese"
    ],
    "population": 10305564,
    "iso": "PT"
}




Now we have France, Portugal and Spain on our db, so lets delete one.

Calling "/delete/{country}" will do it for us. Lets delete France ("delete") and check our db ("AfterDelete").


After all this changes we can check if our countries are still saved, so lets use "/dbCountry/{country}" and search for Spain ("CheckSpain"). Or if we prefer, just get all the saved countries at once we can call "/dbCountry/all" ("CheckAll").
Now all thats left is to update one of our Countries. We obviously can't chance all fields, like Flag, or even the area. Available fields we can edit are "capital", "languages", "currencies" and "population". Lets try and change Portugal languages by adding "Mirandes", check on ("Update") and ("PortugalAfterUpdate").

Finally as the last endpoint, we can check on the current time on any country we wish, calling "/time/{country}", so lets try for Japan. ("JapanTime").
All endpoints also have validations in case you try for example to insert an already existing country , delete a non existent one or try to add a fake country ISO, ("CreateAlreadyExists") , ("DeleteDoesntExist"), ("CreateISONotValid").

And that concludes our demonstration, so lets resume all the endpoints :


GET 	/allData/{country} 	  - Gets all data from the desired country.
GET 	/summarizedData/{country} - Gets the summarized data from the desired country.
POST 	/create 		  - Adds the country to the db, use the summarized body from the previous endpoint, dont forget to change "currencies" and "languages" to Lists.
DELETE  /delete/{country} 	  - Deletes the country from the db.
GET 	/dbCountry/{country} 	  - Gets this country's data from the db.
GET 	/dbCountry/all 	 	  - Gets all countries from db.
POST 	/update/{country} 	  - Updates the data of the choosen country
GET 	/time/{country} 	  - Gets the current time from the required country.
