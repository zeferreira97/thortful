REM INSERTING into LANGUAGES
SET DEFINE OFF;
Insert into LANGUAGES ("countries_name","languages") values ('Spain','Spanish');
Insert into LANGUAGES ("countries_name","languages") values ('Spain','Catalan');
Insert into LANGUAGES ("countries_name","languages") values ('Spain','Basque');
Insert into LANGUAGES ("countries_name","languages") values ('Spain','Galician');
Insert into LANGUAGES ("countries_name","languages") values ('France','French');
