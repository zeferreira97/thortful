REM INSERTING into CAPITALS
SET DEFINE OFF;
Insert into CAPITALS ("countries_name","capital") values ('Spain','Madrid');
Insert into CAPITALS ("countries_name","capital") values ('France','Paris');
