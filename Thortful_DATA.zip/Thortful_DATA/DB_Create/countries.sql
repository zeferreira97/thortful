REM INSERTING into COUNTRIES
SET DEFINE OFF;
Insert into COUNTRIES ("name","area","flag","population","iso","pokemon") values ('France',551695.0,'??',67391582,'FR','spiritomb');
Insert into COUNTRIES ("name","area","flag","population","iso","pokemon") values ('Spain',505992.0,'??',47351567,'ES','tauros');
