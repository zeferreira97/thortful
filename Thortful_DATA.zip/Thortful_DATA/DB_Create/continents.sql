REM INSERTING into CONTINENTS
SET DEFINE OFF;
Insert into CONTINENTS ("countries_name","continents") values ('Spain','Europe');
Insert into CONTINENTS ("countries_name","continents") values ('France','Europe');
