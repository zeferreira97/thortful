REM INSERTING into CURRENCIES
SET DEFINE OFF;
Insert into CURRENCIES ("countries_name","currencies") values ('Spain','Euro');
Insert into CURRENCIES ("countries_name","currencies") values ('France','Euro');
